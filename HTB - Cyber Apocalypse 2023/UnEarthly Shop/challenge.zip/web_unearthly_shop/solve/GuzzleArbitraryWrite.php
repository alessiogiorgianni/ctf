<?php
namespace GuzzleHttp\Cookie {
    class FileCookieJar {
        public $filename;
        public $storeSessionCookies;
        public $cookies;
    }

    class SetCookie {
            public $data;
    }
}