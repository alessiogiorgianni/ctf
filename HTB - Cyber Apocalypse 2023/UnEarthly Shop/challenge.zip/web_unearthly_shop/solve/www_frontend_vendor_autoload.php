<?php

class www_frontend_vendor_autoload {

}