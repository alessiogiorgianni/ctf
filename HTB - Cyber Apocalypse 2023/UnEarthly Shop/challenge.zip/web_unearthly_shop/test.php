<?php

class a {

    public function __destruct(){
        echo "I'm A";
    }
}

class b {

    public function __destruct(){
        echo "I'm B";
    }
}

$vec = [
    "ale" => new a(),
    "sio" => new b()
];

$data = serialize($vec);

unserialize($data);

